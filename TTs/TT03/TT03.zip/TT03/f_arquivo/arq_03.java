/* Seja aos arquivos Pilha.java e Principal Pilha.java (fonte/tad.Estatica),
altere o segundo de tal forma que ele contenha um menu com as opções:
    (1) Inserir
    (2) Remover
    (3) Listar
    (4) Sair,
permitindo inserções, remoções e listar os elementos de uma pilha.
Quando executamos PrincipalPilha, ele lê os elementos da pilha de um arquivo pilha.dat.
Quando o usuário seleciona a opção (4) o programa salva os elementos da pilha no arquivo pilha.dat.
Devemos manter a ordem dos elementos a cada nova execução do PrincipalPilha.
*/
public class arq_03 {
    
}
